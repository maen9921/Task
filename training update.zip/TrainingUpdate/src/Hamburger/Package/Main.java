package Hamburger.Package;

public class Main {
    public static void main(String[] args) {

        Hamburger hamburger=new Hamburger("health burger","Beef",3.5,"roll");
        hamburger.addHamburgerAddition1("tomato",0.75);
        hamburger.addHamburgerAddition2("carrot",3.4);
        hamburger.addHamburgerAddition3("beef",1.5);
        hamburger.itemizeBurger();
        double price=hamburger.itemizeBurger();
        System.out.println(price);
    }
}
