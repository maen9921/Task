package Car.Package;

public class SwitchNum {

    public static  void switchN(int number){
        switch (number){
            case 1:
                new Bmw(12, "720i");
                System.out.println(new Bmw(12,"720i").accelerate());
                new Bmw(12, "720i").startEngine();
                new Bmw(12,"720i").brake();
                break;
            default:
                System.out.println("out of service");

        }
    }
}
