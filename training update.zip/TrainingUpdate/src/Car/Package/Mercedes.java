package Car.Package;

public class Mercedes extends Car{
    public Mercedes(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return "Mercedes -->Start ();";
    }

    @Override
    public String accelerate() {
        return "Mercedes -> accelerate();";
    }

    @Override
    public String brake() {
        return "Mercedes -->break()";
    }
}
