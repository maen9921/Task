package Car.Package;

public class Hyundai extends Car {
    public Hyundai(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return "Hyundai -->Start ();";
    }

    @Override
    public String accelerate() {
        return "Hyundai -> accelerate();";
    }

    @Override
    public String brake() {
        return "Hyundai -->break()";
    }
}
