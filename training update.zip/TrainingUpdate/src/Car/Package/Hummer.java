package Car.Package;

public class Hummer extends Car {
    public Hummer(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return "Hummer -->Start ();";
    }

    @Override
    public String accelerate() {
        return "Hummer -> accelerate();";
    }

    @Override
    public String brake() {
        return "Hummer -->break()";
    }
}
