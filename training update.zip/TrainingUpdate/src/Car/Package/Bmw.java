package Car.Package;

public class Bmw extends Car {
    public Bmw(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return getClass().getSimpleName()+"  Start ();";
    }

    @Override
    public String accelerate() {
        return getClass().getSimpleName()+"  accelerate();";
    }

    @Override
    public String brake() {
        return getClass().getSimpleName()+"   break()";
    }
}
