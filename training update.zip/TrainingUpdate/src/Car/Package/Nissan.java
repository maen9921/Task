package Car.Package;

public class Nissan extends Car {
    public Nissan(int cylinders, String name) {
        super(cylinders, name);
    }

    @Override
    public String startEngine() {
        return"Nissan -->Start ();";
    }

    @Override
    public String accelerate() {
        return "Nissan -> accelerate();";
    }

    @Override
    public String brake() {
        return "Nissan -->break()";
    }
}
