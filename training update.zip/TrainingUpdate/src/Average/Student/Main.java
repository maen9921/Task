package Average.Student;

public class Main {

    public static void main(String[] args) {


//        Switch.printDayOftheWeek(0);
//        Switch.printDayOftheWeek(1);
//        Switch.printDayOftheWeek(2);
//        Switch.printDayOftheWeek(3);
//        Switch.printDayOftheWeek(4);
//        Switch.printDayOftheWeek(5);
//        Switch.printDayOftheWeek(6);
//        Switch.printDayOftheWeek(7);
        calculateInterset(10000,8);


    }
    public static void calculateInterset(double amount ,double intersetRate){
       for (double i=2;i<intersetRate+1;i++){
           System.out.println(amount+" at "+i+"% interest ="+(amount*(i/100)));
       }
    }
}
