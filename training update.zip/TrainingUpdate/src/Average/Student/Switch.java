package Average.Student;

public class Switch {

    public static void printDayOftheWeek(int day){

        switch (day){
            case 0:
                System.out.println("this day Saturday");
                break;
            case 1:
                System.out.println("this day Sunday");
                break;
            case 2:
                System.out.println("this day Monday");
                break;
            case 3:
                System.out.println("this day Tuesday");
                break;
            case 4:
                System.out.println("this day Wednesday");
                break;
            case 5:
                System.out.println("this day Thursday");
                break;
            case 6:
                System.out.println("this day Friday");
                break;
            default:
                System.out.println("invalid Day");
        }
    }
}
