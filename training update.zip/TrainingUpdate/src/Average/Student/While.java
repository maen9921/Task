package Average.Student;

public class While {
    public static void main(String[] args) {

        System.out.println("sum of number is " + sumDigit(125));
        System.out.println("sum of number is " + sumDigit(-1));
        System.out.println("sum of number is " + sumDigit(11111));
    }
//        int number=1;
//        int sumEvenNumber=0;
//        int counter=0;
//        while (number <= 100){
//            if (number% 2==0){
//                System.out.println("number is found is "+number);
//                sumEvenNumber+=number;
//                counter++;
//                if (counter ==5)
//                    break;
//            }
//            number++;
//        }
//        System.out.println("sumEvenNumber = " + sumEvenNumber);

    private static int sumDigit(int number){
        if (number < 10){
            return -1;
        }
        int sum=0;
        while (number > 0){
            int digits=number % 10;
            sum+=digits;
            number /=10;
        }
        return sum;
    }
//private static int sumDigits(int number) {
//
//    if(number < 10) {
//        return -1;
//    }
//
//    int sum = 0;
//
//    // 125 -> 125 / 10 = 12 -> 12 * 10 = 120 -> 125 - 120 = 5
//    while (number >0) {
//        // extract the least-significant digit
//        int digit = number % 10;
//        sum += digit;
//
//        // drop the least-significant digit
//        number /= 10;   // same as number = number / 10;
//    }
//
//    return sum;
//}
}
