package Average.Student.Computer;

public class Main {
    public static void main(String[] args) {
        Case thecase = new Case("220B", "Dell", "240", new Dimensions(20, 20, 5));

        Monitor monitor = new Monitor("27 inch Beast", "acer", new Resolution(2540, 1440), 27);

        MotherBoard motherBoard=new MotherBoard("BJ-200","Asus",4,6,"v2.44");

        Pc pc=new Pc(thecase,monitor,motherBoard);
        pc.getMonitor().drawPixel(1500,1200,"Black");
        pc.getMotherBoard().loadProgram("Windows 1.00");
        pc.getaCase().pressPowerButton();


    }
}
