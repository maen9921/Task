package Average.Student.Computer;

public class Monitor {

    private String model;
    private String manufacture;
    private Resolution nativeResolution;
    private int size;

    public Monitor(String model, String manufacture, Resolution nativeResolution, int size) {
        this.model = model;
        this.manufacture = manufacture;
        this.nativeResolution = nativeResolution;
        this.size = size;
    }

    public void drawPixel (int x, int y ,String colour){
        System.out.println(" Drawing Pixel at  "+x+","+y+" in colour  "+colour);
    }

    public String getModel() {
        return model;
    }

    public String getManufacture() {
        return manufacture;
    }

    public Resolution getNativeResolution() {
        return nativeResolution;
    }

    public int getSize() {
        return size;
    }
}
