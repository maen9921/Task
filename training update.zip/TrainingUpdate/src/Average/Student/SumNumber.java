package Average.Student;

import java.sql.SQLOutput;

public class SumNumber {
    public static void main(String[] args) {
        int number=3;
        int finishNumber=20;
        while (number <= finishNumber){
            number++;
            if (!evenNumber(number)){
                continue;
            }
            System.out.println("even Number is = "+number);
        }
    }
//        int count=0;
//        int sum=0;
//        for (int i = 1; i <=100 ; i++) {
//            if ((i%3==0) && (i%5==0)){
//                count++;
//                sum+=i;
//                System.out.println("Found Number = "+i);
//            }
//            if (count==5)
//                break;
//        }
//        System.out.println("Sum = "+sum);
//    }
    public static boolean evenNumber (int number){
        if (number%2==0)
            return true;
        else
            return false;
    }
}
