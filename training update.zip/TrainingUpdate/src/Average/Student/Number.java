package Average.Student;

public class Number {
    public static void main(String[] args) {

        String numbersString="2018";
        System.out.println("numbers = " + numbersString);

        int numberint=Integer.parseInt(numbersString);
        numbersString+=1;
        numberint+=1;
        System.out.println("after add string "+numbersString);
        System.out.println("after add int "+numberint);

    }
}
