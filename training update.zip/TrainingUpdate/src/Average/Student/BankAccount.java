package Average.Student;

public class BankAccount {
    public static void main(String[] args) {

        Bank customer1 = new Bank(99921, 500, "maen nsour", 772618682, "maen.nsoour@gmail.com");
//        System.out.println(customer1.toString());
//        customer1.deposit(50);
        customer1.withDrawel(500);
        Bank customer2=new Bank();
        System.out.println(customer2.toString());
    }

    public static class Bank {
        private int accountNumber;
        private int balance;
        private String customer_Name;
        private int phoneNumber;
        private String email;

        public Bank (){
            this(0000,0,"Defult Name",99999,"---@email");
            System.out.println("this Empty information please insert data ");
        }

        public Bank(int accountNumber, int balance, String customer_Name, int phoneNumber, String email) {
            this.accountNumber = accountNumber;
            this.balance = balance;
            this.customer_Name = customer_Name;
            this.phoneNumber = phoneNumber;
            this.email = email;
        }

        public int getAccountNumber() {
            return accountNumber;
        }

        public void setAccountNumber(int accountNumber) {
            this.accountNumber = accountNumber;
        }

        public int getBalance() {
            return balance;
        }

        public void setBalance(int balance) {
            this.balance = balance;
        }

        public String getCustomer_Name() {
            return customer_Name;
        }

        public void setCustomer_Name(String customer_Name) {
            this.customer_Name = customer_Name;
        }

        public int getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(int phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public void deposit(int money) {
            this.balance += money;
            System.out.println("this your Balance is =  " + balance);
        }

        public void withDrawel(int money) {
            if (balance - money < 0) {
                System.out.println("this Operation is rejected\n" +
                        "Balance is not enough");
            } else
                this.balance -= money;
            System.out.println("this Balance is = " + balance);

        }

        @Override
        public String toString() {
            return "Bank{" +
                    "accountNumber=" + accountNumber +
                    ", balance=" + balance +
                    ", customer_Name='" + customer_Name + '\'' +
                    ", phoneNumber=" + phoneNumber +
                    ", email='" + email + '\'' +
                    '}';
        }
    }
}
