package Average.Player;

public class Main {
    public static void main(String[] args) {

        EnhancedPlayer enhancedPlayer=new EnhancedPlayer("maen nsour","Magnum",-5);
        
        System.out.println("initial health is "+enhancedPlayer.getHealth());
    }
}
