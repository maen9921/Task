package Average.Movies;

public class MazeRunner extends Movie {
    public MazeRunner() {
        super("MazeRunner");
    }

    @Override
    public String plot() {
        return "kids try and escape a Maze";
    }
}
