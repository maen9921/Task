package Average.Movies;

public class IndependanceDay extends Movie {
    public IndependanceDay() {
        super("IndependanceDay");
    }

    @Override
    public String plot() {
        return "Aliens attempt  to take over planet earth ";
    }
}
