package Average.Movies;

public class StarWars extends Movie {
    public StarWars() {
        super("Star Wars");
    }

    @Override
    public String plot() {
        return "imperial forces try to take over the universe";
    }
}
