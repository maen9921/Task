package Average.Movies;

public class Forgettable extends Movie {
    public Forgettable() {
        super("Forgettable");
    }
    //no plots Method ;
}
