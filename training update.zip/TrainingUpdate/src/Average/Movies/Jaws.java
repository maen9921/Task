package Average.Movies;

public class Jaws extends Movie {
    public Jaws() {
        super("jaws");
    }

    @Override
    public String plot() {
        return " A shark eats a lot of pepole ";
    }
}
